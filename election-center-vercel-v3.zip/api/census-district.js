const { cached, TTL, CENSUS_KEY, json, fetchJson } = require("./_util");
const FIPS = {
  AL:"01",AK:"02",AZ:"04",AR:"05",CA:"06",CO:"08",CT:"09",DE:"10",
  FL:"12",GA:"13",HI:"15",ID:"16",IL:"17",IN:"18",IA:"19",KS:"20",
  KY:"21",LA:"22",ME:"23",MD:"24",MA:"25",MI:"26",MN:"27",MS:"28",
  MO:"29",MT:"30",NE:"31",NV:"32",NH:"33",NJ:"34",NM:"35",NY:"36",
  NC:"37",ND:"38",OH:"39",OK:"40",OR:"41",PA:"42",RI:"44",SC:"45",
  SD:"46",TN:"47",TX:"48",UT:"49",VT:"50",VA:"51",WA:"53",WV:"54",
  WI:"55",WY:"56"
};

module.exports = async (req, res) => {
  try {
    const state = String(req.query.state || "").toUpperCase();
    const cd = String(req.query.cd ?? "");
    if (!FIPS[state]) return json(res, 400, { error: "bad state" });
    const district = cd === "0" || cd.toUpperCase() === "AL"
      ? "00"
      : cd.padStart(2, "0");
    const data = await cached(`acs:${state}:${district}`, TTL.CENSUS, async () => {
      const variables = [
        "DP05_0001E",
        "DP03_0062E",
        "DP02_0068PE",
        "DP05_0018E",
        "DP03_0128PE",
        "DP04_0046PE"
      ];
      const url = new URL("https://api.census.gov/data/2024/acs/acs5/profile");
      url.searchParams.set("get", variables.join(","));
      url.searchParams.set("for", `congressional district:${district}`);
      url.searchParams.set("in", `state:${FIPS[state]}`);
      if (CENSUS_KEY()) url.searchParams.set("key", CENSUS_KEY());
      const rows = await fetchJson(url.toString());
      if (!rows?.[1]) throw new Error("No Census district row returned");
      const header = rows[0];
      const row = rows[1];
      const value = name => {
        const index = header.indexOf(name);
        if (index === -1) return null;
        const raw = row[index];
        return raw == null || Number(raw) < 0 ? null : Number(raw);
      };
      const population = value("DP05_0001E");
      const income = value("DP03_0062E");
      const bachelors = value("DP02_0068PE");
      const medianAge = value("DP05_0018E");
      const poverty = value("DP03_0128PE");
      const ownerOccupied = value("DP04_0046PE");
      return {
        source: "U.S. Census Bureau 2024 ACS 5-Year Data Profile",
        profile: {
          Population: population == null ? null : population.toLocaleString("en-US"),
          "Median household income": income == null ? null : `$${income.toLocaleString("en-US")}`,
          "Bachelor's or higher": bachelors == null ? null : `${bachelors}%`,
          "Median age": medianAge,
          "Poverty rate": poverty == null ? null : `${poverty}%`,
          "Owner-occupied housing": ownerOccupied == null ? null : `${ownerOccupied}%`
        }
      };
    });
    return json(res, 200, data, 30 * 24 * 60 * 60);
  } catch (error) {
    return json(res, 500, { error: error.message }, 60);
  }
};
