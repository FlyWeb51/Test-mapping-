const fs = require("fs").promises;
const path = require("path");
const { json } = require("./_util");

module.exports = async function handler(req, res) {
  try {
    const raceId = String(req.query.race_id || req.query.race || "").trim();
    const file = path.join(__dirname, "polls-data.json");
    let raw = "[]";
    try { raw = await fs.readFile(file, "utf8"); } catch (_) {}
    const all = JSON.parse(raw);
    const polls = (Array.isArray(all) ? all : []).filter(poll => {
      const approved = poll.reviewStatus === "approved";
      const sameRace = !raceId || poll.raceId === raceId;
      return approved && sameRace;
    });
    return json(res, 200, { raceId, count: polls.length, polls }, 1800);
  } catch (error) {
    return json(res, 500, { error: error.message }, 60);
  }
};
