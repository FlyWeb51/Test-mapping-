const memory = globalThis.__electionCenterCache || new Map();
globalThis.__electionCenterCache = memory;

const MINUTE = 60 * 1000;
const HOUR = 60 * MINUTE;
const DAY = 24 * HOUR;

const TTL = {
  FEC_RACE: 12 * HOUR,
  FEC_TOTALS: 12 * HOUR,
  FEC_IE: 4 * HOUR,
  CENSUS: 30 * DAY,
  FCC_FOLDER: 2 * HOUR,
  POLLS: 30 * MINUTE
};

async function cached(key, ttl, loader) {
  const hit = memory.get(key);
  if (hit && Date.now() - hit.at < ttl) return hit.value;
  const value = await loader();
  memory.set(key, { at: Date.now(), value });
  return value;
}

function FEC_KEY() {
  return process.env.FEC || process.env.FEC_API_KEY || "DEMO_KEY";
}
function CENSUS_KEY() {
  return process.env.CENSUS_API_KEY || "";
}

function json(res, status, body, cdnSeconds = 300) {
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.setHeader(
    "Cache-Control",
    `public, s-maxage=${cdnSeconds}, stale-while-revalidate=${cdnSeconds}`
  );
  return res.status(status).json(body);
}

async function fetchJson(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: {
      Accept: "application/json",
      "User-Agent": "ElectionCenter/0.3",
      ...(options.headers || {})
    },
    signal: AbortSignal.timeout(10000)
  });
  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Upstream ${response.status}: ${text.slice(0, 240)}`);
  }
  return response.json();
}

module.exports = { cached, TTL, FEC_KEY, CENSUS_KEY, json, fetchJson };
