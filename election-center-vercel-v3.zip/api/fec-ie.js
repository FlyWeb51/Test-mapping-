const { cached, TTL, FEC_KEY, json, fetchJson } = require("./_util");

module.exports = async (req, res) => {
  try {
    const candidateId = String(req.query.candidate_id || req.query.cand || "").trim();
    const cycle = Number(req.query.cycle || 2026);
    if (!candidateId) return json(res, 400, { error: "candidate_id is required" });
    const data = await cached(`fec-ie:${candidateId}:${cycle}`, TTL.FEC_IE, async () => {
      const u = new URL("https://api.open.fec.gov/v1/schedules/schedule_e/by_candidate/by_committee/");
      u.searchParams.set("api_key", FEC_KEY());
      u.searchParams.set("candidate_id", candidateId);
      u.searchParams.set("cycle", String(cycle));
      u.searchParams.set("per_page", "100");
      const raw = await fetchJson(u.toString());
      const rows = raw.results || [];
      const totals = rows.reduce((acc, r) => {
        const side = String(r.support_oppose_indicator || "U").toUpperCase();
        const amount = Number(r.total || r.expenditure_amount || 0);
        if (side === "S") acc.support += amount;
        else if (side === "O") acc.oppose += amount;
        else acc.unknown += amount;
        return acc;
      }, { support: 0, oppose: 0, unknown: 0 });
      return { candidate_id: candidateId, cycle, totals, committees: rows };
    });
    return json(res, 200, data, 4 * 60 * 60);
  } catch (e) {
    return json(res, 500, { error: e.message }, 60);
  }
};
