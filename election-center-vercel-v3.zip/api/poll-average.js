const fs = require("fs").promises;
const path = require("path");

function ageInDays(dateString) {
  const end = new Date(`${dateString}T23:59:59Z`);
  return Math.max(0, (Date.now() - end.getTime()) / 86400000);
}
function weight(poll) {
  const recency = Math.exp(-ageInDays(poll.endDate) / 30);
  const sample = Math.sqrt(Math.max(100, Number(poll.sampleSize || 400)) / 400);
  const population = poll.population === "LV" ? 1.15 : poll.population === "RV" ? 1 : 0.85;
  const internal = poll.internal ? 0.7 : 1;
  return recency * sample * population * internal;
}

module.exports = async function handler(req, res) {
  try {
    const raceId = String(req.query.race_id || "").trim();
    if (!raceId) return res.status(400).json({ error: "race_id is required" });
    const raw = await fs.readFile(path.join(__dirname, "polls-data.json"), "utf8");
    const polls = JSON.parse(raw).filter(
      poll => poll.reviewStatus === "approved" && poll.raceId === raceId
    );
    if (!polls.length) {
      return res.status(404).json({ error: "No approved polls found" });
    }
    const totals = new Map();
    let totalWeight = 0;
    for (const poll of polls) {
      const pollWeight = weight(poll);
      totalWeight += pollWeight;
      for (const result of poll.results || []) {
        const key = result.candidateId || result.candidate;
        const saved = totals.get(key) || {
          candidate: result.candidate,
          party: result.party,
          weighted: 0
        };
        saved.weighted += Number(result.percentage) * pollWeight;
        totals.set(key, saved);
      }
    }
    const average = [...totals.entries()]
      .map(([candidateId, value]) => ({
        candidateId,
        candidate: value.candidate,
        party: value.party,
        percentage: Number((value.weighted / totalWeight).toFixed(1))
      }))
      .sort((a, b) => b.percentage - a.percentage);
    res.setHeader("Cache-Control", "public, s-maxage=1800, stale-while-revalidate=3600");
    return res.status(200).json({
      raceId,
      pollCount: polls.length,
      average,
      includedPollIds: polls.map(poll => poll.id)
    });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
};
