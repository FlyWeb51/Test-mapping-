// County-level ACS profile for every county in a selected state.
const { cached, TTL, CENSUS_KEY, json, fetchJson } = require("./_util");
const FIPS = {
  AL:"01", AK:"02", AZ:"04", AR:"05", CA:"06", CO:"08", CT:"09", DE:"10",
  FL:"12", GA:"13", HI:"15", ID:"16", IL:"17", IN:"18", IA:"19", KS:"20",
  KY:"21", LA:"22", ME:"23", MD:"24", MA:"25", MI:"26", MN:"27", MS:"28",
  MO:"29", MT:"30", NE:"31", NV:"32", NH:"33", NJ:"34", NM:"35", NY:"36",
  NC:"37", ND:"38", OH:"39", OK:"40", OR:"41", PA:"42", RI:"44", SC:"45",
  SD:"46", TN:"47", TX:"48", UT:"49", VT:"50", VA:"51", WA:"53", WV:"54",
  WI:"55", WY:"56"
};

function numberOrNull(value) {
  if (value == null || value === "" || !Number.isFinite(Number(value)) || Number(value) < 0) {
    return null;
  }
  return Number(value);
}

module.exports = async function censusCounty(req, res) {
  try {
    const state = String(req.query.state || "").trim().toUpperCase();
    if (!FIPS[state]) {
      return json(res, 400, {
        error: "Invalid state abbreviation",
        received: state || null,
        example: "/api/census-county?state=AZ"
      });
    }
    const data = await cached(`acs-counties:2024:${state}`, TTL.CENSUS, async () => {
      const variables = [
        "NAME",
        "DP05_0001E", // Population
        "DP03_0062E", // Median household income
        "DP02_0068PE", // Bachelor's degree or higher
        "DP03_0128PE"  // Poverty rate
      ];
      const url = new URL("https://api.census.gov/data/2024/acs/acs5/profile");
      url.searchParams.set("get", variables.join(","));
      url.searchParams.set("for", "county:*");
      url.searchParams.set("in", `state:${FIPS[state]}`);
      const key = CENSUS_KEY();
      if (key) url.searchParams.set("key", key);
      const rows = await fetchJson(url.toString());
      if (!Array.isArray(rows) || rows.length < 2 || !Array.isArray(rows[0])) {
        throw new Error("Census returned an unexpected response format");
      }
      const header = rows[0];
      const column = name => header.indexOf(name);
      for (const required of [...variables, "state", "county"]) {
        if (column(required) === -1) {
          throw new Error(`Census response is missing ${required}`);
        }
      }
      const counties = rows.slice(1).map(row => {
        const population = numberOrNull(row[column("DP05_0001E")]);
        const income = numberOrNull(row[column("DP03_0062E")]);
        const bachelors = numberOrNull(row[column("DP02_0068PE")]);
        const poverty = numberOrNull(row[column("DP03_0128PE")]);
        return {
          name: row[column("NAME")],
          population: population == null ? null : population.toLocaleString("en-US"),
          income: income == null ? null : `$${income.toLocaleString("en-US")}`,
          bachelors: bachelors == null ? null : `${bachelors}%`,
          poverty: poverty == null ? null : `${poverty}%`,
          state_fips: row[column("state")],
          county_fips: row[column("county")]
        };
      }).sort((a, b) => a.name.localeCompare(b.name));
      return {
        source: "U.S. Census Bureau 2024 ACS 5-Year Data Profile",
        state,
        count: counties.length,
        counties
      };
    });
    return json(res, 200, data, 30 * 24 * 60 * 60);
  } catch (error) {
    console.error("census-county error:", error);
    return json(res, 500, {
      error: "County demographics could not be loaded",
      details: error.message
    });
  }
};
