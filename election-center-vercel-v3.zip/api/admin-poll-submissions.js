const crypto = require("node:crypto");

function fingerprint(poll) {
  const normalized = [
    poll.pollster,
    poll.raceId,
    poll.startDate,
    poll.endDate,
    Number(poll.sampleSize || 0)
  ].map(value => String(value || "").trim().toLowerCase()).join("|");
  return crypto.createHash("sha256").update(normalized).digest("hex");
}

module.exports = async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Method not allowed" });
  }
  const expected = process.env.POLL_INGEST_TOKEN;
  const supplied = String(req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  if (!expected || supplied !== expected) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  const poll = req.body || {};
  const required = ["pollster", "raceId", "startDate", "endDate", "sourceUrl", "results"];
  const missing = required.filter(
    field => !poll[field] || (field === "results" && !Array.isArray(poll.results))
  );
  if (missing.length) {
    return res.status(400).json({ error: "Missing required fields", missing });
  }
  const submission = {
    id: crypto.randomUUID(),
    ...poll,
    fingerprint: fingerprint(poll),
    reviewStatus: "pending",
    discoveredAt: new Date().toISOString()
  };
  // First release: returns the validated record. Vercel's filesystem is read-only at
  // runtime, so a 201 here does NOT mean the poll persisted — connect Supabase/Neon/
  // Vercel Postgres before treating submissions as saved.
  return res.status(201).json({ submission });
};
