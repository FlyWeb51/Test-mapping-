const { cached, TTL, FEC_KEY, json, fetchJson } = require("./_util");

module.exports = async (req, res) => {
  try {
    const state = String(req.query.state || "").toUpperCase();
    const district = String(req.query.district || "").padStart(2, "0");
    const office = String(req.query.office || "H").toUpperCase();
    const cycle = Number(req.query.cycle || 2026);
    if (!/^[A-Z]{2}$/.test(state)) {
      return json(res, 400, { error: "bad state" });
    }
    const data = await cached(
      `fec-race:${state}:${district}:${office}:${cycle}`,
      TTL.FEC_RACE,
      async () => {
        const url = new URL("https://api.open.fec.gov/v1/candidates/search/");
        url.searchParams.set("api_key", FEC_KEY());
        url.searchParams.set("state", state);
        url.searchParams.set("office", office);
        url.searchParams.set("cycle", String(cycle));
        if (office === "H") url.searchParams.set("district", district);
        url.searchParams.set("per_page", "100");
        const found = await fetchJson(url.toString());

        const seen = new Set();
        const distinct = (found.results || []).filter(candidate => {
          if (!candidate.candidate_id || seen.has(candidate.candidate_id)) return false;
          seen.add(candidate.candidate_id);
          return true;
        });

        // Cap parallel totals lookups: an uncapped Promise.all over a crowded race
        // can trip the FEC hourly rate limit and the serverless timeout at once.
        const capped = distinct.slice(0, 20);
        const candidates = await Promise.all(capped.map(async candidate => {
          const totalsUrl = new URL(
            `https://api.open.fec.gov/v1/candidate/${encodeURIComponent(candidate.candidate_id)}/totals/`
          );
          totalsUrl.searchParams.set("api_key", FEC_KEY());
          totalsUrl.searchParams.set("cycle", String(cycle));
          totalsUrl.searchParams.set("per_page", "1");
          let totals = null;
          try {
            const totalsResponse = await fetchJson(totalsUrl.toString());
            const raw = totalsResponse.results?.[0];
            if (raw) {
              totals = {
                receipts: raw.receipts,
                disbursements: raw.disbursements,
                cash_on_hand: raw.last_cash_on_hand_end_period ?? raw.cash_on_hand_end_period,
                debts: raw.last_debts_owed_by_committee,
                coverage_end_date: raw.coverage_end_date
              };
            }
          } catch (_) {}
          return {
            candidate_id: candidate.candidate_id,
            name: candidate.name,
            party: candidate.party,
            incumbent_challenge:
              candidate.incumbent_challenge_full || candidate.incumbent_challenge,
            candidate_status: candidate.candidate_status,
            totals
          };
        }));
        candidates.sort(
          (a, b) => (b.totals?.receipts || 0) - (a.totals?.receipts || 0)
        );
        return { state, district, office, cycle, total_filed: distinct.length, candidates };
      }
    );
    return json(res, 200, data, 12 * 60 * 60);
  } catch (error) {
    return json(res, 500, { error: error.message }, 60);
  }
};
