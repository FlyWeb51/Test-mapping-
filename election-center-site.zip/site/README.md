# Election Center — first-draft site

Map + data dashboard for the 2026 midterms, built to the First-Draft Guide:
FEC candidate finance as the headline metric, manual polling with a transparent
average, Census ACS district context, and an FCC public-files reader as an
advertising-activity signal.

## Run it locally

1. Install Node.js 18+ (nodejs.org)
2. In this folder: `npm install`
3. `cp .env.example .env` and paste your keys:
   - FEC key: https://api.data.gov/signup/ (instant, free)
   - Census key: https://api.census.gov/data/key_signup.html (free)
4. `npm start`
5. Open http://localhost:3000

The same frontend also works as a plain file with no backend — backend-only
sections (district profile, polls) explain themselves when the server is absent.

## Endpoints

- `/api/fec/totals?cand=H0TX15..` or `?q=lastname&office=H&state=TX` — cached candidate totals
- `/api/fec/ie?cand=H0TX15..` — independent expenditures for/against
- `/api/census/district?state=TX&cd=15` — ACS profile (population, income, education, age, poverty, housing)
- `/api/polls?race=TX-15` — entries from `data/polls.json` plus a simple mean average
- `/api/fcc/folder?url=<publicfiles.fcc.gov folder>` — PDF records in an FCC political folder

## Add a poll (60 seconds)

Edit `data/polls.json`, add an entry under the race id (e.g. `"TX-15"`), restart
not required — the file is read per request.

## Build order status (from the guide)

- Phase 1 Candidate/race table — DONE (embedded in frontend, all 435 + 100)
- Phase 2 FEC totals + comparison — DONE (totals, burn rate; add opponent comparison next)
- Phase 3 Polling table + average — DONE (manual entry)
- Phase 4 Census district profile — DONE (6 high-value variables)
- Phase 5 District map — DONE (real boundaries embedded; TIGERweb refresh later)
- Phase 6 OpenStates link-out — NEXT
- Phase 7 FCC folder reader — DONE (metadata stage; PDF extraction later)
- Phase 8 Manual previous-election results — NEXT

## Deploy

GitHub Pages can host only the frontend (`public/index.html`). For the backend,
use a free tier at Render, Railway, or Fly.io: connect the repo, set the two
env vars in their dashboard, done.

Security rule from the guide: API keys live in `.env` / host env vars only.
