// server.js — Election Center backend (first draft)
// Follows the First-Draft Guide: keys live here in env vars, never in browser JS.
// npm install express cheerio dotenv
require("dotenv").config();
const express = require("express");
const { readPoliticalFolder } = require("./fcc-reader");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const FEC_KEY = process.env.FEC_API_KEY || "DEMO_KEY";
const CENSUS_KEY = process.env.CENSUS_API_KEY || "";

/* ---------- tiny cache so public traffic never burns API limits ---------- */
const cache = new Map();
async function cached(key, ttlMs, fn) {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.t < ttlMs) return hit.v;
  const v = await fn();
  cache.set(key, { t: Date.now(), v });
  return v;
}
const H6 = 6 * 3600 * 1000, D30 = 30 * 86400 * 1000;

/* ---------- FEC: candidate totals (Phase 2 of the build order) ---------- */
app.get("/api/fec/totals", async (req, res) => {
  try {
    const { cand = "", q = "", office = "H", state = "" } = req.query;
    const data = await cached(`fec:${cand}:${q}:${office}:${state}`, H6, async () => {
      let cid = cand;
      if (!cid) {
        const sr = await (await fetch(
          `https://api.open.fec.gov/v1/candidates/search/?api_key=${FEC_KEY}&q=${encodeURIComponent(q)}&office=${office}&state=${state}&per_page=5`
        )).json();
        cid = sr.results?.[0]?.candidate_id;
      }
      if (!cid) return { error: "no candidate ID found" };
      const tr = await (await fetch(
        `https://api.open.fec.gov/v1/candidate/${cid}/totals/?api_key=${FEC_KEY}&sort=-cycle&per_page=1`
      )).json();
      return { candidate_id: cid, totals: tr.results?.[0] || null };
    });
    res.json(data);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

/* ---------- FEC: independent expenditures for/against a candidate ---------- */
app.get("/api/fec/ie", async (req, res) => {
  try {
    const { cand = "", cycle = "2026" } = req.query;
    if (!cand) return res.status(400).json({ error: "cand required" });
    const data = await cached(`ie:${cand}:${cycle}`, H6, async () => {
      const r = await (await fetch(
        `https://api.open.fec.gov/v1/schedules/schedule_e/by_candidate/?api_key=${FEC_KEY}&candidate_id=${cand}&cycle=${cycle}&election_full=true&per_page=10`
      )).json();
      let support = 0, oppose = 0;
      (r.results || []).forEach(x => x.support_oppose_indicator === "S" ? support += x.total : oppose += x.total);
      return { support, oppose, net: support - oppose };
    });
    res.json(data);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

/* ---------- Census ACS district profile (Phase 4) ---------- */
const FIPS = {AL:"01",AK:"02",AZ:"04",AR:"05",CA:"06",CO:"08",CT:"09",DE:"10",FL:"12",GA:"13",HI:"15",ID:"16",IL:"17",IN:"18",IA:"19",KS:"20",KY:"21",LA:"22",ME:"23",MD:"24",MA:"25",MI:"26",MN:"27",MS:"28",MO:"29",MT:"30",NE:"31",NV:"32",NH:"33",NJ:"34",NM:"35",NY:"36",NC:"37",ND:"38",OH:"39",OK:"40",OR:"41",PA:"42",RI:"44",SC:"45",SD:"46",TN:"47",TX:"48",UT:"49",VT:"50",VA:"51",WA:"53",WV:"54",WI:"55",WY:"56"};
app.get("/api/census/district", async (req, res) => {
  try {
    const st = String(req.query.state || "").toUpperCase();
    const cd = String(req.query.cd ?? "");
    if (!FIPS[st]) return res.status(400).json({ error: "bad state" });
    const cdCode = (cd === "0" || cd === "AL") ? "00" : cd.padStart(2, "0");
    const data = await cached(`acs:${st}:${cdCode}`, D30, async () => {
      // Small high-value variable set, per the first-draft guide
      const vars = "DP05_0001E,DP03_0062E,DP02_0068PE,DP05_0018E,DP03_0128PE,DP04_0046PE";
      const url = `https://api.census.gov/data/2023/acs/acs5/profile?get=${vars}&for=congressional%20district:${cdCode}&in=state:${FIPS[st]}${CENSUS_KEY ? "&key=" + CENSUS_KEY : ""}`;
      const rows = await (await fetch(url)).json();
      const v = rows[1];
      const n = x => (x == null || +x < 0) ? null : +x;
      return { profile: {
        "Population": n(v[0])?.toLocaleString("en-US"),
        "Median household income": n(v[1]) ? "$" + n(v[1]).toLocaleString("en-US") : null,
        "Bachelor's or higher": n(v[2]) != null ? n(v[2]) + "%" : null,
        "Median age": n(v[3]),
        "Poverty rate": n(v[4]) != null ? n(v[4]) + "%" : null,
        "Owner-occupied housing": n(v[5]) != null ? n(v[5]) + "%" : null
      }};
    });
    res.json(data);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

/* ---------- Manual polling table + transparent average (Phase 3) ---------- */
app.get("/api/polls", (req, res) => {
  try {
    const race = String(req.query.race || "");
    const all = JSON.parse(fs.readFileSync(path.join(__dirname, "data", "polls.json"), "utf8"));
    const polls = all[race] || [];
    const sums = {}, counts = {};
    polls.forEach(p => Object.entries(p.results || {}).forEach(([k, v]) => {
      sums[k] = (sums[k] || 0) + +v; counts[k] = (counts[k] || 0) + 1;
    }));
    const average = {};
    Object.keys(sums).forEach(k => average[k] = sums[k] / counts[k]);
    res.json({ race, polls, average });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

/* ---------- FCC public-files folder reader (Phase 7) ---------- */
app.get("/api/fcc/folder", async (req, res) => {
  try {
    const folderUrl = String(req.query.url || "");
    const records = await readPoliticalFolder(folderUrl);
    res.json({ folderUrl, count: records.length, records });
  } catch (error) {
    console.error(error);
    res.status(400).json({ error: error.message });
  }
});

app.use(express.static(path.join(__dirname, "public")));
app.listen(PORT, () => console.log(`Election Center running on http://localhost:${PORT}`));
