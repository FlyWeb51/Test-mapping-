# Election Center — GitHub + Vercel

Upload this repository to GitHub exactly as packaged.

## Required layout

```text
index.html
package.json
README.md
api/
  _util.js
  census-county.js
  census-district.js
  fcc-folder.js
  fec-ie.js
  fec-race.js
  fec-totals.js
  polls-data.json
  polls.js
```

## Deploy

1. Create a GitHub repository and upload the contents of this ZIP.
2. Import the GitHub repository into Vercel.
3. In Vercel, open **Settings → Environment Variables**.
4. Add `FEC_API_KEY` and `CENSUS_API_KEY`.
5. Redeploy the project.

## API routes

- `/api/fec-totals`
- `/api/fec-race`
- `/api/fec-ie`
- `/api/census-district`
- `/api/census-county`
- `/api/polls`
- `/api/fcc-folder`

Edit `api/polls-data.json` to add polling data. Each GitHub commit automatically triggers a new Vercel deployment.

GitHub Pages alone cannot run the `/api` serverless functions. Use the GitHub repository as the source and Vercel as the deployed test website.
