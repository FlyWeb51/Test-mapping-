const { cached, H6, FEC_KEY, json, fetchJson } = require("./_util");

module.exports = async (req, res) => {
  try {
    const cand = String(req.query.cand || "").trim();
    const q = String(req.query.q || "").trim();
    const office = String(req.query.office || "").toUpperCase();
    const state = String(req.query.state || "").toUpperCase();
    if (!cand && !q) return json(res, 400, { error: "cand or q is required" });

    const result = await cached(`fec-totals:${cand}:${q}:${office}:${state}`, H6, async () => {
      let candidateId = cand;
      if (!candidateId) {
        const u = new URL("https://api.open.fec.gov/v1/candidates/search/");
        u.searchParams.set("api_key", FEC_KEY());
        u.searchParams.set("q", q);
        if (office) u.searchParams.set("office", office);
        if (state) u.searchParams.set("state", state);
        u.searchParams.set("per_page", "10");
        const found = await fetchJson(u);
        candidateId = found.results?.[0]?.candidate_id || "";
      }
      if (!candidateId) return { candidate_id: null, totals: null };

      const u = new URL(`https://api.open.fec.gov/v1/candidate/${encodeURIComponent(candidateId)}/totals/`);
      u.searchParams.set("api_key", FEC_KEY());
      u.searchParams.set("sort", "-cycle");
      u.searchParams.set("per_page", "1");
      const data = await fetchJson(u);
      return { candidate_id: candidateId, totals: data.results?.[0] || null };
    });
    return json(res, 200, result);
  } catch (e) {
    return json(res, 500, { error: e.message });
  }
};
