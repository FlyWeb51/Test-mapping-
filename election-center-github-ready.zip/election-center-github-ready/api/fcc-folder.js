const { cached, H6, json, fetchJson } = require("./_util");

function list(payload) {
  if (Array.isArray(payload)) return payload;
  for (const key of ["results", "data", "items", "files", "folders", "entities"]) {
    if (Array.isArray(payload?.[key])) return payload[key];
  }
  return [];
}

module.exports = async (req, res) => {
  try {
    const keyword = String(req.query.keyword || req.query.station || "").trim();
    const folderId = String(req.query.folderId || "").trim();
    if (!keyword && !folderId) return json(res, 400, { error: "keyword or folderId is required" });

    const data = await cached(`fcc:${keyword}:${folderId}`, H6, async () => {
      if (folderId) {
        const url = `https://publicfiles.fcc.gov/api/manager/folder/id/${encodeURIComponent(folderId)}.json`;
        const raw = await fetchJson(url);
        return { mode: "folder", folder_id: folderId, items: list(raw), raw };
      }
      const url = `https://publicfiles.fcc.gov/api/service/facility/search/${encodeURIComponent(keyword)}`;
      const raw = await fetchJson(url);
      return { mode: "facility-search", keyword, facilities: list(raw), raw };
    });
    return json(res, 200, data);
  } catch (e) { return json(res, 500, { error: e.message }); }
};
