const fs = require("fs");
const path = require("path");
const { json } = require("./_util");

module.exports = async (req, res) => {
  try {
    const race = String(req.query.race || "").trim();
    const file = path.join(__dirname, "polls-data.json");
    const all = JSON.parse(fs.readFileSync(file, "utf8"));
    const polls = (Array.isArray(all) ? all : []).filter(p => !race || p.race === race);
    const sums = {}, counts = {};
    for (const p of polls) for (const [name, value] of Object.entries(p.results || {})) {
      const v = Number(value); if (!Number.isFinite(v)) continue;
      sums[name] = (sums[name] || 0) + v; counts[name] = (counts[name] || 0) + 1;
    }
    const average = {};
    for (const name of Object.keys(sums)) average[name] = sums[name] / counts[name];
    return json(res, 200, { race, polls, average });
  } catch (e) { return json(res, 500, { error: e.message }); }
};
