const { cached, H6, FEC_KEY, json, fetchJson } = require("./_util");

module.exports = async (req, res) => {
  try {
    const state = String(req.query.state || "").toUpperCase();
    const district = String(req.query.district || "").padStart(2, "0");
    const office = String(req.query.office || "H").toUpperCase();
    const cycle = Number(req.query.cycle || 2026);
    if (!/^[A-Z]{2}$/.test(state)) return json(res, 400, { error: "bad state" });

    const data = await cached(`fec-race:${state}:${district}:${office}:${cycle}`, H6, async () => {
      const u = new URL("https://api.open.fec.gov/v1/candidates/search/");
      u.searchParams.set("api_key", FEC_KEY());
      u.searchParams.set("state", state);
      u.searchParams.set("office", office);
      u.searchParams.set("cycle", String(cycle));
      if (office === "H") u.searchParams.set("district", district);
      u.searchParams.set("per_page", "100");
      const found = await fetchJson(u);
      const seen = new Set();
      const candidates = [];

      for (const c of found.results || []) {
        if (!c.candidate_id || seen.has(c.candidate_id)) continue;
        seen.add(c.candidate_id);
        const t = new URL(`https://api.open.fec.gov/v1/candidate/${encodeURIComponent(c.candidate_id)}/totals/`);
        t.searchParams.set("api_key", FEC_KEY());
        t.searchParams.set("cycle", String(cycle));
        t.searchParams.set("per_page", "1");
        let totals = null;
        try {
          const tr = await fetchJson(t);
          const raw = tr.results?.[0];
          if (raw) totals = {
            receipts: raw.receipts,
            disbursements: raw.disbursements,
            cash_on_hand: raw.last_cash_on_hand_end_period ?? raw.cash_on_hand_end_period,
            debts: raw.last_debts_owed_by_committee,
            coverage_end_date: raw.coverage_end_date
          };
        } catch (_) {}
        candidates.push({
          candidate_id: c.candidate_id,
          name: c.name,
          party: c.party,
          incumbent_challenge: c.incumbent_challenge_full || c.incumbent_challenge,
          candidate_status: c.candidate_status,
          totals
        });
      }
      candidates.sort((a, b) => (b.totals?.receipts || 0) - (a.totals?.receipts || 0));
      return { state, district, office, cycle, candidates };
    });
    return json(res, 200, data);
  } catch (e) {
    return json(res, 500, { error: e.message });
  }
};
