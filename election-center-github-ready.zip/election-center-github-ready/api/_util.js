const memory = globalThis.__electionCenterCache || new Map();
globalThis.__electionCenterCache = memory;

const D30 = 30 * 24 * 60 * 60 * 1000;
const H6 = 6 * 60 * 60 * 1000;

async function cached(key, ttl, loader) {
  const hit = memory.get(key);
  if (hit && Date.now() - hit.at < ttl) return hit.value;
  const value = await loader();
  memory.set(key, { at: Date.now(), value });
  return value;
}

function FEC_KEY() {
  return process.env.FEC_API_KEY || "DEMO_KEY";
}

function CENSUS_KEY() {
  return process.env.CENSUS_API_KEY || "";
}

function json(res, status, body) {
  res.status(status);
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.setHeader("Cache-Control", "s-maxage=300, stale-while-revalidate=86400");
  return res.json(body);
}

async function fetchJson(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: {
      Accept: "application/json",
      "User-Agent": "ElectionCenter/0.2",
      ...(options.headers || {})
    },
    signal: AbortSignal.timeout(20000)
  });
  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Upstream ${response.status}: ${text.slice(0, 240)}`);
  }
  return response.json();
}

module.exports = { cached, D30, H6, FEC_KEY, CENSUS_KEY, json, fetchJson };
